#' @section Stopwords: 
#' 
#' Stopword lists were formerly built into \pkg{quanteda}, but have been moved to the 
#' \pkg{stopwords} package.  See \code{\link[stopwords]{stopwords}}.
#' @import stopwords
#' @export 
stopwords::stopwords
