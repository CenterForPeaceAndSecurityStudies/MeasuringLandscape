#ifndef ARMA_64BIT_WORD
#define ARMA_64BIT_WORD  
#endif

#ifndef ARMA_DONT_PRINT_OPENMP_WARNING
//#define ARMA_DONT_USE_OPENMP
#define ARMA_DONT_PRINT_OPENMP_WARNING
#endif
#include <RcppArmadillo.h>
