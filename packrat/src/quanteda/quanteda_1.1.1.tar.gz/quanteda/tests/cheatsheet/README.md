# quanteda Cheatsheet materials

The cheatsheet itself is in Powerpoint; some supplemental R files create the images.



