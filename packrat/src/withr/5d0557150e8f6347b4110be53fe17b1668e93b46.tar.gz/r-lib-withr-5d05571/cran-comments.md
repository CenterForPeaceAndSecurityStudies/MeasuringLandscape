This release fixes errors with testthat 2.0

## Test environments
* OS X El Capitan, R 3.4.2
* ubuntu 12.04 (on travis-ci), R 3.4.2, 3.3.3, 3.2.5, 3.1, R-devel
* Windows Server 2012 R2 (x64), R 3.4.2
* Rhub

## R CMD check results
There were no NOTEs, ERRORs or WARNINGs.

## Downstream dependencies
* I ran R CMD check on all 42 downstream dependencies of withr
  Summary at: https://github.com/r-lib/withr/tree/master/revdep#readme
