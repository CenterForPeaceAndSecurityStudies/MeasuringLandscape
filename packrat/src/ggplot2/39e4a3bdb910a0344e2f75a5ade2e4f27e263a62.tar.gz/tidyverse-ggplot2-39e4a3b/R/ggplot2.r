#' @keywords internal
"_PACKAGE"

#' @import scales grid gtable
#' @importFrom plyr defaults
#' @importFrom stats setNames
NULL
