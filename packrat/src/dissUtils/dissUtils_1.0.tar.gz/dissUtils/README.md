dissUtils
=============

an R package that can perform a variety of distance/dissimilarity operations between matrices or the rows of a matrix. It includes a C++ framework for creating and including new dissimilarity measures.
