.known.methods <- c(
                    "braycurtis",
                    "canberra",
                    "chebyshev",
                    "covariance",
                    "euclidean",
                    "equality",
                    "hellinger",
                    "jaccard",
                    "mahalanobis",
                    "manhattan",
                    "minkowski",
                    "pearson",
                    "procrustes"
                    );

